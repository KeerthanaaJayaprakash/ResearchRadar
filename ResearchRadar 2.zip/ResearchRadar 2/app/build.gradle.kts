plugins {
    alias(libs.plugins.androidApplication)
}

android {
    namespace = "com.example.researchradar"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.researchradar"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    buildFeatures {
        viewBinding = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
//    testOptions {
//        unitTests {
//            includeAndroidResources = true
//        }
//    }
//    testOptions.unitTests.includeAndroidResources = true
    testOptions.unitTests.isIncludeAndroidResources = true

}

dependencies {

    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    implementation(libs.swiperefreshlayout)
    testImplementation(libs.junit)
    testImplementation("junit:junit:4.12")
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
    implementation("com.android.volley:volley:1.2.1")
    implementation ("com.google.android.material:material:1.2.1")
    testImplementation("androidx.test.espresso:espresso-core:3.4.0")
    testImplementation("androidx.test:runner:1.4.0")
    testImplementation("androidx.test:rules:1.4.0")
    testImplementation("androidx.test.espresso:espresso-contrib:3.1.0")
//    testImplementation("androidx.test.espresso:espresso-intents:3.4.0")
    androidTestImplementation("com.android.support.test.espresso:espresso-core:3.0.2")
    androidTestImplementation("com.android.support.test.espresso:espresso-contrib:3.0.2:3.0.2")
    androidTestImplementation("com.android.support.test:runner:1.0.2")
    androidTestImplementation("com.android.support.test:rules:1.0.2")
//    RUnner("androidx.test.runner.AndroidJUnitRunner")
    testImplementation("androidx.arch.core:core-testing:2.1.0")
    testImplementation("org.robolectric:robolectric:4.12")
    testImplementation("androidx.test:core:1.5.0")

    testImplementation("org.mockito:mockito-core:3.6.28")


    androidTestImplementation("androidx.test:runner:1.5.2")

}