package com.example.researchradar;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.researchradar.SQLite.DBHandler;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DetailsActivity extends AppCompatActivity {
    TextView name, tag, citedCount, citedLink, versionLink, domain;
    String alphaName, alphaTag, alphacitedCount, alphacitedLink, alphaversionLink, alphadomain;
    Button save;

    private DBHandler dbHandler;
    int alphaImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
//        imageView = findViewById(R.id.image);
        dbHandler = new DBHandler(DetailsActivity.this);

        name = findViewById(R.id.name);
        tag = findViewById(R.id.tag);
        citedCount  = findViewById(R.id.cited);
        citedLink = findViewById(R.id.citedlink);
        versionLink = findViewById(R.id.versionlink);
        domain = findViewById(R.id.domain);

        save = findViewById(R.id.save);
        //get the intent
        alphaName = getIntent().getStringExtra("name");
        alphaTag = getIntent().getStringExtra("tag");
        alphadomain = getIntent().getStringExtra("domain");
        alphacitedLink = getIntent().getStringExtra("citedlink");
        alphacitedCount = getIntent().getStringExtra("cited");
        alphaversionLink = getIntent().getStringExtra("versionlink");

        //now set the get values in the respective widgets
        name.setText(alphaName);
        tag.setText(alphaTag);
        domain.setText(alphadomain);
        citedCount.setText(alphacitedCount);
        citedLink.setText(alphacitedLink);
        versionLink.setText(alphaversionLink);
//        save.setAllowClickWhenDisabled();
        int isExists = dbHandler.checkPaperExists(alphaversionLink);
        if(isExists >= 1){
            save.setEnabled(false);
            save.setText("Saved");
        }
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save.setEnabled(false);
                save.setText("Saved");
                dbHandler.addNewPaper(alphaName, alphaTag,alphacitedCount, alphacitedLink, alphaversionLink,alphadomain);

            }
        });

//        imageView.setImageResource(alphaImage);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}