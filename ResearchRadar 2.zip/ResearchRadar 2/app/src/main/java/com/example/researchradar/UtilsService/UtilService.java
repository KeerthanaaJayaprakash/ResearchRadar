package com.example.researchradar.UtilsService;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.google.android.material.snackbar.Snackbar;

public class UtilService {
    public void hideKeyboard(Activity activity){
        try{

            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
            //Find the currently focused view, so we can grab the correct window token from it.
            View view = activity.getCurrentFocus();
            //If no view currently has focus, create a new one, just so we can grab a window token from it
            if (view == null) {
                view = new View(activity);
            }
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
   }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void closeKeyboardFromFragment(Activity activity, View view) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        // hide the keyboard
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public void showSnackBar(View view, String msg){

        Snackbar.make(view,msg,Snackbar.LENGTH_LONG)

                .setBackgroundTint(Color.rgb(237,67,55))
                .setTextColor(Color.WHITE)
                .show();
    }
    public void showSnackBarSuccess(View view, String msg){

        Snackbar.make(view,msg,Snackbar.LENGTH_LONG)
                .setBackgroundTint(Color.rgb(34, 139, 34))
                .setTextColor(Color.WHITE)
                .show();
    }
    public String IPAddr(){

        String BaseURL = "http://192.168.1.217:4444/";


        return BaseURL;
    }

}
