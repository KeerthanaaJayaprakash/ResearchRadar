package com.example.researchradar;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.researchradar.SQLite.DBHandler;
import com.example.researchradar.SQLite.PaperModal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;


public class UserDownloads extends Fragment {
    View view;
    RecyclerView recyclerView;
    List<Papers> modelList;
    RecyclerView.Adapter adapter;
    SwipeRefreshLayout refreshLayout;
    private ArrayList<PaperModal> paperModalArrayList;
    private DBHandler dbHandler;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        view =  inflater.inflate(R.layout.fragment_user_downloads, container, false);
        refreshLayout = view.findViewById(R.id.refresh);
        refreshLayout.setOnRefreshListener(() -> {

            getFragmentManager().beginTransaction().detach(UserDownloads.this).attach(UserDownloads.this).commit();
            refreshLayout.setRefreshing(false);

        });
        recyclerView = view.findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        recyclerView.setHasFixedSize(true);
        modelList = new ArrayList<>();

        dbHandler = new DBHandler(getContext());
        ArrayList<PaperModal> courseModalArrayList = new ArrayList<>();
        courseModalArrayList = dbHandler.readCourses();




        for(int i = 0; i<courseModalArrayList.size(); i++){
            PaperModal data = courseModalArrayList.get(i);
            String title = data.getName();
            String snippet = data.getTag();
            String citedCount =data.getcitedCount();
            String citedLink =data.getcitedLink();
            String versionLink = data.getversionLink();
            String domain=data.getDomain();
            modelList.add(new Papers(title, snippet, citedCount,domain, citedLink,versionLink));
            System.out.println("title "+title+"snippet "+snippet+"cited count "+citedCount+"citedLink "+citedLink+"versionLink "+versionLink+"Domain "+domain);
        }
        adapter = new PaperAdapter(modelList,getContext());
        //set the adapter into recyclerView
        recyclerView.setAdapter(adapter);
        return view;
    }
}