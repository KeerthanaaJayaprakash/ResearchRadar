package com.example.researchradar;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.ServerError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.researchradar.PaperAdapter;
import com.example.researchradar.UtilsService.UtilService;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserHome extends Fragment {
    Button searchBT;
    EditText keywordsET;
    String keyword;
    UtilService utilService;
    SwipeRefreshLayout refreshLayout;
    RecyclerView recyclerView;

    RecyclerView recycler;
    List<Papers> modelList;
    RecyclerView.Adapter adapter;
    View view;
 @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
     view = inflater.inflate(R.layout.fragment_user_home, container, false);
//     LayoutInflater.from(parent.context).inflate(R.layout.layout_category_item, parent, false)

     searchBT = view.findViewById(R.id.search);
     keywordsET = view.findViewById(R.id.searchBar);
     utilService = new UtilService();
//     recyclerView = view.findViewById(R.id.recyclerView);

     refreshLayout = view.findViewById(R.id.refresh);
     refreshLayout.setOnRefreshListener(() -> {

     getFragmentManager().beginTransaction().detach(UserHome.this).attach(UserHome.this).commit();
     refreshLayout.setRefreshing(false);

     });

     recyclerView = view.findViewById(R.id.recyclerView);


     recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
     recyclerView.setHasFixedSize(true);
     searchBT.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             utilService.hideKeyboard(getActivity());
             final InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
             imm.hideSoftInputFromWindow(getView().getWindowToken(), 0);
             keyword = keywordsET.getText().toString();
//             View viewK = (View) getView().getRootView().getWindowToken();

//             utilService.hideKeyboard(view, getContext());

             searchPaper(v, view);
         }
     });




     return view;

//     return inflater.inflate(R.layout.fragment_user_home, container, false);
    }
    public void searchPaper(View v, View view){
        String BaseURL = utilService.IPAddr();
        String Route = "search/searchPaper";
        String apiKey = BaseURL+Route;

        final HashMap<String, String> params = new HashMap<>();
        params.put("keyword", keyword);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST,
                apiKey, new JSONObject(params), new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d("¸", "onResponse: MySightings response"+response.toString());

                try {
                    if(response.getBoolean("success")) {

                        modelList = new ArrayList<>();

//                        String User = response.getString("user");
                        JSONArray jsonArray = response.getJSONArray("paper");
//                        JSONObject jsonObject = response.getJSONObject("user");
                        Log.d("LoginPage", "onResponse: UserJSONUSER"+jsonArray);
                        for(int i=0; i<jsonArray.length();i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            Log.d("PrintPaper","Resp: "+jsonObject);

                            String title = jsonObject.optString("title");
                            String domain = jsonObject.optString("domain");
                            String snippet = jsonObject.optString("snippet");
                            String citedCount = jsonObject.optString("cited_by_count");
                            String citedLink = jsonObject.optString("cited_by_link");
                            String versionLink = jsonObject.optString("versions_link");
                            modelList.add(new Papers(title, snippet, citedCount,citedLink,versionLink, domain));

                        }
                        //call our items

                        adapter = new PaperAdapter(modelList,getContext());
                        //set the adapter into recyclerView
                        recyclerView.setAdapter(adapter);

                    }
//                    progressBar.setVisibility(View.GONE);
                } catch (JSONException e) {
                    e.printStackTrace();
//                    progressBar.setVisibility(View.GONE);
                }
            }

//            private void displayList( View view) {
                public void displayList(JSONObject papersPrint, View view) {

                    Log.d("UserHome", "displayList Inside");





            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                NetworkResponse response = error.networkResponse;
                if(error instanceof ServerError && response != null) {
                    try {
                        String res = new String(response.data, HttpHeaderParser.parseCharset(response.headers,  "utf-8"));

                        JSONObject obj = new JSONObject(res);
                        utilService.showSnackBar(view, obj.getString("msg"));

//                        progressBarar.setVisibility(View.GONE);
                    } catch (JSONException | UnsupportedEncodingException je) {
                        je.printStackTrace();
//                        progressBararsBar.setVisibility(View.GONE);
                    }
                }
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                return params;
            }
        };

        // set retry policy
        int socketTime = 3000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTime,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        jsonObjectRequest.setRetryPolicy(policy);

        // request add
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(jsonObjectRequest);




    }
}