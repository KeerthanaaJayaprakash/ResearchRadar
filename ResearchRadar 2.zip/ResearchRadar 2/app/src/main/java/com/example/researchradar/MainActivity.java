package com.example.researchradar;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.ServerError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.Volley;
import com.example.researchradar.UtilsService.UtilService;
import com.example.researchradar.UtilsService.SharedPreferenceClass;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import android.view.inputmethod
        .InputMethodManager;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class MainActivity extends AppCompatActivity {
    private Button login;
    private EditText  email_ET, password_ET;
    Button createAccount;
    //    String email, password;
    ProgressBar progressBar;
    private String email,password;
    UtilService utilService;
    SharedPreferenceClass sharedPreferences;
    String notificationToken;
    TextView credits;
    SharedPreferenceClass sharedPreferenceClass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        sharedPreferenceClass = new SharedPreferenceClass(this);

        login = (Button) findViewById(R.id.login);
        email_ET = (EditText) findViewById(R.id.username);
        password_ET = (EditText) findViewById(R.id.password);

        utilService = new UtilService();
        createAccount = (Button) findViewById(R.id.register);
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Signup.class));

            }

        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                utilService.hideKeyboard(MainActivity.this);

                email = email_ET.getText().toString();
                password = password_ET.getText().toString();

                if(validateInput(email, password))
                    Login(v);
            }


        });
    }

        public boolean validateInput( String email, String password) {
            View view = getCurrentFocus();
            final String PASSWORD_PATTERN =
                    "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#&()–[{}]:;',?/*~$^+=<>]).{8,20}$";
            final Pattern pattern = Pattern.compile(PASSWORD_PATTERN);
            if (!(!email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches())) {
                utilService.showSnackBar(view, "Enter valid Email ID");
                return false;
            }
            Matcher matcher = pattern.matcher(password);
            if (!matcher.matches()){
                utilService.showSnackBar(view, "Enter valid password");
                return false;
            }

            return true;
        }


    protected void onStart() {

        super.onStart();
        SharedPreferences researchRadar = getSharedPreferences("researchRadar",MODE_PRIVATE);
        sharedPreferenceClass = new SharedPreferenceClass(this);
//        String email = sharedPreferences.getValue_string("email");
        String loggedIn = researchRadar.getString("email","");
        if(!loggedIn.equals("")){
            startActivity(new Intent(MainActivity.this, Navigation.class));
            finish();
        }


    }
    private void Login(View view){
        String BaseURL = utilService.IPAddr();
//        String BaseURL = "http://192.0.0.2:4444/";
        String Route = "users/login";

        String apiKey = BaseURL+Route;


        final HashMap<String, String> params = new HashMap<>();
        params.put("password", password);
        params.put("email", email);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST,
                apiKey, new JSONObject(params), new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d("¸", "onResponse: MySightings response"+response.toString());

                try {
                    if(response.getBoolean("success")) {
                        String User = response.getString("user");
                        JSONObject jsonObject = response.getJSONObject("user");


                        sharedPreferenceClass.setValue_string("email", jsonObject.get("email").toString());
                        sharedPreferenceClass.setValue_string("name", jsonObject.get("name").toString());
                        sharedPreferenceClass.setValue_string("phone", jsonObject.get("phone").toString());
                        startActivity(new Intent(MainActivity.this, Navigation.class));


                    }

                } catch (JSONException e) {
                    e.printStackTrace();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                NetworkResponse response = error.networkResponse;
                if(error instanceof ServerError && response != null) {
                    try {
                        String res = new String(response.data, HttpHeaderParser.parseCharset(response.headers,  "utf-8"));

                        JSONObject obj = new JSONObject(res);
                        utilService.showSnackBar(view, obj.getString("msg"));


                    } catch (JSONException | UnsupportedEncodingException je) {
                        je.printStackTrace();

                    }
                }
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                return params;
            }
        };

        // set retry policy
        int socketTime = 3000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTime,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        jsonObjectRequest.setRetryPolicy(policy);

        // request add
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonObjectRequest);




    }
}