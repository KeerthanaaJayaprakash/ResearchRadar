package com.example.researchradar;
public class Papers {
    String name, tag;
    String citedCount;
    String citedLink;
    String versionLink;
    String domain;
    int id;
    public Papers() {
    }
    public Papers(String name, String tag, String citedCount, String citedLink, String versionLink, String domain) {
//        this.image = image;
        this.name = name;
        this.tag = tag;
        this.citedCount = citedCount;
        this.versionLink = versionLink;
        this.citedLink = citedLink;
        this.domain = domain;


    }
    public String getDomain() {
        return domain;
    }
    public void setdomain(String domain) {
        this.domain = domain;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getTag() {
        return tag;
    }
    public void setTag(String tag) {
        this.tag = tag;
    }
    public String getcitedCount() {
        return citedCount;
    }
    public void setcitedCount(String citedCount) {
        this.citedCount = citedCount;
    }
    public String getversionLink() {
        return versionLink;
    }
    public void setversionLink(String versionLink) {
        this.versionLink = versionLink;
    }
    public String getcitedLink() {
        return citedLink;
    }
    public void setcitedLink(String citedLink) {
        this.citedLink = citedLink;
    }
}