package com.example.researchradar;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

import android.os.Looper;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.versioning.AndroidVersions;

@RunWith(RobolectricTestRunner.class)
public class LoginTest {

    @Test
    public void validateTest(){
        MainActivity obj = new MainActivity();
        assertTrue(obj.validateInput("example@gmail.com", "AAAa@aa123"));
    }
    @Test
    public void invalidEmail(){
        MainActivity obj = new MainActivity();
        assertFalse(obj.validateInput("examplegmail.com", "AAA@aaa123"));
    }
    @Test
    public void invalidPassword(){
        MainActivity obj = new MainActivity();
        assertFalse(obj.validateInput("example@gmail.com", "AAAAAaaaa123"));
    }




}