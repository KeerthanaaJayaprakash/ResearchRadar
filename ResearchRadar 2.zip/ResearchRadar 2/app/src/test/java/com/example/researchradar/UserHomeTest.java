package com.example.researchradar;

import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.versioning.AndroidVersions;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertEquals;
import static org.robolectric.versioning.AndroidVersions.*;

import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.rule.ActivityTestRule;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

    @RunWith(AndroidJUnit4.class)
    public class UserHomeTest {

        @Rule
        public ActivityTestRule<Navigation> activityRule = new ActivityTestRule<>(Navigation.class);

        @Before
        public void setUp() {
            // Replace the existing fragment with the UserHomeFragment
            Fragment userHomeFragment = new UserHome();
            activityRule.getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.userHomeContainer, userHomeFragment)
                    .commit();
        }

        @Test
        public void testRecyclerViewItemClick() {
            // Click on an item in the RecyclerView
            onView(withId(R.id.recyclerView))
                    .perform(RecyclerViewActions.actionOnItemAtPosition(0, click()));

            // Perform assertions or further actions as needed
        }

        // Add more test methods as needed for other interactions or assertions
    }
