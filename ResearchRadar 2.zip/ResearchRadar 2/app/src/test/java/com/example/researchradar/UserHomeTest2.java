package com.example.researchradar;

import static org.junit.Assert.*;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class UserHomeTest2{

    @Mock
    private View mockView;

    @Mock
    private Button mockButton;

    @Mock
    private EditText mockEditText;

    private UserHome userHome;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        userHome = new UserHome();
    }

    @Test
    public void testSearchButtonClick() {
        // Mock input values
        String keyword = "example keyword";
        when(mockEditText.getText().toString()).thenReturn(keyword);

        // Set up the fragment's views
        when(mockView.findViewById(R.id.search)).thenReturn(mockButton);
        when(mockView.findViewById(R.id.searchBar)).thenReturn(mockEditText);

        // Call the onClick method of the search button
//        userHome.onClick(mockButton);

        // Verify that the searchPaper method is called with the correct keyword
        verify(userHome).searchPaper(mockButton, mockView);
    }
}

