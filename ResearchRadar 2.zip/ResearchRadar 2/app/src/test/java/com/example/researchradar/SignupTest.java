package com.example.researchradar;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.typeText;
import static org.junit.Assert.*;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.matcher.ViewMatchers;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class SignupTest {

    @Test
    public void validateInput(){
        Signup obj = new Signup();
        assertFalse(obj.validateInput("example@gmail.com", "AAAaaa123","AAAA"));
//        assertTrue(obj.validateInput("arun7@gmail.com", "AAAa@aa123"));

    }
    @Test
    public void validateMatchPassword(){
        Signup obj = new Signup();
        assertTrue(obj.validateInput("example@gmail.com", "AAAaaa123@","AAAaaa123@"));

    }
    @Test
    public void invalidEmail(){
        Signup obj = new Signup();
        assertFalse(obj.validateInput("examplwgmail.com", "AAA@123ss","AAA@123ss"));
    }

}