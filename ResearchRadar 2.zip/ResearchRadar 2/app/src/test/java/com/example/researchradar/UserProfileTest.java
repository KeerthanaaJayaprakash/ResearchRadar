package com.example.researchradar;

import static org.junit.Assert.*;

import androidx.fragment.app.Fragment;
import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertEquals;

import android.view.View;

@RunWith(AndroidJUnit4.class)
@LargeTest

public class UserProfileTest {


    @Rule
    public ActivityTestRule<Navigation> activityRule = new ActivityTestRule<>(Navigation.class);

    @Before
    public void setUp() {
        // Replace the existing fragment with the UserHomeFragment
        Fragment userProfileFragment = new UserProfile();
        activityRule.getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.frameLayout, userProfileFragment)
                .commit();
    }

    @Test
    public void testFinishActivity() {
        // Perform actions or assertions
        // Call finish() on the main thread
        activityRule.getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                activityRule.getActivity().finish();
//                onView(withId(R.id.name)).check(matches(withText("Arun")));
//                onView(withId(R.id.username)).check(matches(withText("Arun27@gmail.com")));
            }
        });
        onView(withId(R.id.name)).check(matches(withText("Team5")));
        onView(withId(R.id.username)).check(matches(withText("Team5@gmail.com")));
    }
}