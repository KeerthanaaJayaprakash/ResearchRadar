package com.example.researchradar;

//import androidx.test.ext.junit.runners.AndroidJUnit4;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.Visibility.VISIBLE;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isRoot;
import static androidx.test.espresso.matcher.ViewMatchers.withEffectiveVisibility;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.ViewInteraction;
//import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.regex.Matcher;

@RunWith(AndroidJUnit4.class)
@LargeTest
public class UserHomeTest3 {
    @Rule
    public ActivityTestRule<Navigation> activityRule = new ActivityTestRule<>(Navigation.class);

    @Before
    public void setUp() {
        // Replace the existing fragment with the UserHomeFragment
        Fragment userHomeFragment = new UserHome();
        activityRule.getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.frameLayout, userHomeFragment)
                .commit();
    }
    @Test
    public void T001_T003() throws InterruptedException {
        // Type text into the EditText
        ViewInteraction perform = onView(withId(R.id.searchBar)).perform(typeText("Hello"));

        // Click the button
        onView(withId(R.id.search)).perform(click());
        Thread.sleep(10000);
        onView(withId(R.id.recyclerView))
                .perform(RecyclerViewActions.actionOnItemAtPosition(0, click()));
    }

}