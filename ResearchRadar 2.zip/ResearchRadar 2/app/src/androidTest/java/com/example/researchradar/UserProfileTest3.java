package com.example.researchradar;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import androidx.fragment.app.Fragment;
import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
@LargeTest

public class UserProfileTest3 {


    @Rule
    public ActivityTestRule<Navigation> activityRule = new ActivityTestRule<>(Navigation.class);

    @Before
    public void setUp() {
        // Replace the existing fragment with the UserHomeFragment
        Fragment userProfileFragment = new UserProfile();
        activityRule.getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.frameLayout, userProfileFragment)
                .commit();
    }
    @Test
    public void T008() throws InterruptedException {
        // Perform actions or assertions
        // Call finish() on the main thread
        Thread.sleep(10000);

//        onView(withId(R.id.name)).xcheck(matches(withText("Arun")));
        onView(withId(R.id.username)).check(matches(withText("Team5@gmail.com")));
        onView(withId(R.id.name)).check(matches(withText("Team5")));
        onView(withId(R.id.phone)).check(matches(withText("9999999")));
        Thread.sleep(10000);
    }
}