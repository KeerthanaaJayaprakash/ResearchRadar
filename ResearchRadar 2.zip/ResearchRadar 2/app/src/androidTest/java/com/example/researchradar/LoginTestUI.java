package com.example.researchradar;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.junit.Assert.*;

import androidx.test.espresso.ViewInteraction;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.rule.ActivityTestRule;

import org.junit.Rule;
import org.junit.Test;

public class LoginTestUI {
    @Rule
    public ActivityTestRule<MainActivity> activityRule = new ActivityTestRule<>(MainActivity.class);

    @Test
    public void T006() throws InterruptedException {
        // Type text into the EditText
        onView(withId(R.id.username)).perform(typeText("Team5@gmail.com"));
        onView(withId(R.id.password)).perform(typeText("Team5@2710"));
        onView(withId(R.id.login)).perform(click());
        Thread.sleep(10000);
            }

}