package com.example.researchradar;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.junit.Assert.*;

import androidx.fragment.app.Fragment;
import androidx.test.espresso.ViewInteraction;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.rule.ActivityTestRule;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

public class DownloadTest {

    @Rule
    public ActivityTestRule<Navigation> activityRule = new ActivityTestRule<>(Navigation.class);

    @Before
    public void setUp() {
        // Replace the existing fragment with the UserHomeFragment
        Fragment userHomeFragment = new UserHome();
        activityRule.getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.frameLayout, userHomeFragment)
                .commit();
    }
    @Test
    public void T002() throws InterruptedException {
        // Type text into the EditText
        ViewInteraction perform = onView(withId(R.id.searchBar)).perform(typeText("Bluetooth"));

        // Click the button
        onView(withId(R.id.search)).perform(click());
        Thread.sleep(10000);
        onView(withId(R.id.recyclerView))
                .perform(RecyclerViewActions.actionOnItemAtPosition(0, click()));
        onView(withId(R.id.save)).perform(click());
        Thread.sleep(10000);


    }

}