const data = require("./dataJson");
// import data from './dataJson';
console.log(data.data.scholar_results[0])