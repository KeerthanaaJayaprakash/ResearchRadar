const express = require("express");
const colors = require("colors");
const morgan = require("morgan");
const router = express.Router();
const User = require("../models/User");
// const Overall = require("../models/Overall");

// const func = require("../utilities/functions");

const bcryptjs = require("bcryptjs");

router.get("/test", (req, res) => {
    console.log("Test");
    res.status(200).json({
        success: false,
        msg: "It Works",
    });
});


router.post("/signup", async (req, res, next) => {
    console.log("register");
    const {
        name,
        password,
        email,
        phone,
    } = req.body;

    // console.log(name)
    // console.log(password)
    // console.log(email)

    try {
        let user_exists = await User.findOne({ email: email });
        if (user_exists) {
            return res.status(400).json({
                success: false,
                msg: "User Already Exists",
            });
        }
        let user = new User();
        user.email = email;
        user.name = name;
        user.phone = phone;

        const salt = await bcryptjs.genSalt(10);
        user.password = await bcryptjs.hash(password, salt);

        await user.save();
        console.log(user);
        return res.status(200).json({
            success: true,
            msg: "User Registered",
        });
    } catch (err) {
        console.log(err);
    }
});


router.post("/userProfile", async (req, res, next) => {
    // console.log(req);

    const email = req.body.email;
    console.log("Dashboard " + email.green.bold);

    try {


        // let overall = await Overall.findOne();
        let user = await User.findOne({ email: email });
        if (!user) {
            console.log("Invalid User".red.bold);
            return res.status(400).json({
                success: false,
                msg: "User Not Exists",
            });
        } else {
            console.log("Success Dashboard")
            return res.status(200).json({
                success: true,
                msg: "User Dashboard in",
                user: user,
            });
        }
    } catch (err) {
        console.log(err);
    }
});

router.post("/login", async (req, res, next) => {
    console.log("Login" + req.body);

    const email = req.body.email;
    const password = req.body.password;
    // const notificationToken = req.body.notificationToken;
    // console.log(notificationToken + " Token");
    try {
        let user = await User.findOne({
            email: email,
        });
        if (!user) {
            return res.status(400).json({
                success: false,
                msg: "User Not Exists",
            });
        }
        const isMatch = await bcryptjs.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({
                success: false,
                msg: "Invalid Password",
            });
        } else {
            console.log(user);


            console.log("User Logged in Successfully".green.bold);
            res.status(200).json({
                success: true,
                msg: "User Logged in",
                user: user,
            });



        }
    } catch (err) {
        console.log(err);
        return res.status(500).json({
            success: false,
            msg: "Server Error",
        });
    }
});
router.post("/register", async (req, res, next) => {
    console.log("register");
    const {
        username,
        name,
        password,
        phone,
    } = req.body;
    try {
        let user_exists = await User.findOne({ username: username });
        if (user_exists) {
            return res.status(400).json({
                success: false,
                msg: "User Already Exists",
            });
        }
        let user = new User();
        user.username = username;
        user.name = name;
        user.phone = phone;
        const salt = await bcryptjs.genSalt(10);
        user.password = await bcryptjs.hash(password, salt);

        await user.save();

        return res.status(200).json({
            success: true,
            msg: "User Registered",
        });
    } catch (err) {
        console.log(err);
    }
});

module.exports = router;
