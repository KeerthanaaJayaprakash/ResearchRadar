const express = require("express");
const colors = require("colors");
const morgan = require("morgan");
const router = express.Router();
const User = require("../models/User");
const axios = require('axios');
const data = require("../dataJson");
const Papers = require('../models/Papers');
// const Overall = require("../models/Overall");

// const func = require("../utilities/functions");

const bcryptjs = require("bcryptjs");


router.post("/searchPaper",async (req, res, next)=>{
    console.log("register");
    console.log(req.body)
    keyword = req.body.keyword
    // var results = fetchData(keyword);
    let papersss = await Papers.find({ 'search_parameters.q': keyword});
    // console.log("222222222222")
    console.log(papersss)


    if(papersss.length == 0){
        fetchData(keyword).then(res =>{     
            console.log(res);
            AddPapertoDB(res);
            resPaper = res;
        })
    }
    await sleep(5000);
    // else{
    let paperss = await Papers.find({ 'search_parameters.q': keyword});
    resPaper = paperss[0]
    // }
    // AddPapertoDB(res)
    // console.log("#######################")
    // console.log(res)



    try{
        // const dataReturned = data.data
        // AddPapertoDB(dataReturned)
        papersList = resPaper.scholar_results
        // console.log(papersList)
        return res.status(200).json({
            success: true,
            msg: "Papers Fetched",
            paper: papersList,
        });
        
    }catch(err){
        console.log(err);
    }

});

function sleep(ms) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
  }
  

// getData()
// .then(res => console.log(res))
async function fetchData(keyword){
    var results;
    const params = {
        api_key: "1309E7D70BD240F5AA828E0010EA5E8A",
        search_type: "scholar",
        q: keyword
        }

        try {
            const res = await axios.get('https://api.scaleserp.com/search', { params });
            if(res.status == 200){
                // test for status you want, etc
                console.log(res.status)
            }   
             return res.data

        } catch (error) {
            // Handle errors
            console.log(error);

        }

}


async function AddPapertoDB(data){
    // console.log(data);
    let paper = new Papers();
    // paper = {dataReturned};
    // console.log(paper)

    console.log(data.search_parameters)
    paper.request_info = data.request_info
    paper.search_parameters = data.search_parameters
    paper.search_metadata = data.search_metadata
    paper.search_information = data.search_information
    paper.pagination = data.pagination
    paper.scholar_results = data.scholar_results
    // console.log(dataReturned)
    await paper.save();
    return paper;

}



router.get("/test", (req, res) => {
    console.log("Test");
    res.status(200).json({
        success: false,
        msg: "It Works",
    });
});


router.post("/signup", async (req, res, next) => {
    console.log("register");
    const {
        name,
        password,
        email,
        phone,
    } = req.body;

    try {
        let user_exists = await User.findOne({ email: email });
        if (user_exists) {
            return res.status(400).json({
                success: false,
                msg: "User Already Exists",
            });
        }
        let user = new User();
        user.email = email;
        user.name = name;
        user.phone = phone;

        const salt = await bcryptjs.genSalt(10);
        user.password = await bcryptjs.hash(password, salt);

        await user.save();

        return res.status(200).json({
            success: true,
            msg: "User Registered",
        });
    } catch (err) {
        console.log(err);
    }
});


router.post("/userProfile", async (req, res, next) => {
    // console.log(req);

    const email = req.body.email;
    console.log("Dashboard " + email.green.bold);

    try {


        // let overall = await Overall.findOne();
        let user = await User.findOne({ email: email });
        if (!user) {
            console.log("Invalid User".red.bold);
            return res.status(400).json({
                success: false,
                msg: "User Not Exists",
            });
        } else {
            console.log("Success Dashboard")
            return res.status(200).json({
                success: true,
                msg: "User Dashboard in",
                user: user,
            });
        }
    } catch (err) {
        console.log(err);
    }
});

router.post("/login", async (req, res, next) => {
    console.log("Login" + req.body);

    const email = req.body.email;
    const password = req.body.password;
    // const notificationToken = req.body.notificationToken;
    // console.log(notificationToken + " Token");
    try {
        let user = await User.findOne({
            email: email,
        });
        if (!user) {
            return res.status(400).json({
                success: false,
                msg: "User Not Exists",
            });
        }
        const isMatch = await bcryptjs.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({
                success: false,
                msg: "Invalid Password",
            });
        } else {
            console.log(user);
    

            console.log("User Logged in Successfully".green.bold);
            res.status(200).json({
                success: true,
                msg: "User Logged in",
                user: user,
            });



        }
    } catch (err) {
        console.log(err);
        return res.status(500).json({
            success: false,
            msg: "Server Error",
        });
    }
});
router.post("/register", async (req, res, next) => {
    console.log("register");
    const {
        username,
        name,
        password,
        phone,
    } = req.body;
    try {
        let user_exists = await User.findOne({ username: username });
        if (user_exists) {
            return res.status(400).json({
                success: false,
                msg: "User Already Exists",
            });
        }
        let user = new User();
        user.username = username;
        user.name = name;
        user.phone = phone;
        const salt = await bcryptjs.genSalt(10);
        user.password = await bcryptjs.hash(password, salt);

        await user.save();

        return res.status(200).json({
            success: true,
            msg: "User Registered",
        });
    } catch (err) {
        console.log(err);
    }
});

module.exports = router;
