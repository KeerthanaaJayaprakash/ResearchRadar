// const { data } = require("cheerio/lib/api/attributes")

let data = {
    "request_info":{
        "success":true,
        "credits_used":9,
        "credits_used_this_request":1,
        "credits_remaining":116,
        "credits_reset_at":"2024-04-15T19:34:33.000Z"
    },
    "search_parameters":{
        "search_type":"scholar",
        "q":"Bluetooth",
        "id":"req0",
        "page":"2",
        "engine":"google"
    },
    "search_metadata":{
        "created_at":"2024-03-28T17:53:34.691Z",
        "processed_at":"2024-03-28T17:53:38.325Z",
        "total_time_taken":3.63,
        "engine_url":"https://www.google.com/scholar?q=Bluetooth&start=10",
        "html_url":"https://api.scaleserp.com/search?api_key=1309E7D70BD240F5AA828E0010EA5E8A&search_type=scholar&q=Bluetooth&page=2&engine=google&output=html",
        "json_url":"https://api.scaleserp.com/search?api_key=1309E7D70BD240F5AA828E0010EA5E8A&search_type=scholar&q=Bluetooth&page=2&engine=google&output=json"
    },
    "search_information":{
        "original_query_yields_zero_results":false,
        "total_results":836000,
        "time_taken_displayed":0.08,
        "query_displayed":"Bluetooth"
    },
    "pagination":{
        "current":2,
        "next":"https://www.google.com/scholar?start=20&q=Bluetooth&hl=it&as_sdt=0,5",
        "other_pages":[
            {
                "page":1,
                "link":"https://www.google.com/scholar?start=0&q=Bluetooth&hl=it&as_sdt=0,5"
            },
            {
                "page":3,
                "link":"https://www.google.com/scholar?start=20&q=Bluetooth&hl=it&as_sdt=0,5"
            },
            {
                "page":4,
                "link":"https://www.google.com/scholar?start=30&q=Bluetooth&hl=it&as_sdt=0,5"
            },
            {
                "page":5,
                "link":"https://www.google.com/scholar?start=40&q=Bluetooth&hl=it&as_sdt=0,5"
            },
            {
                "page":6,
                "link":"https://www.google.com/scholar?start=50&q=Bluetooth&hl=it&as_sdt=0,5"
            },
            {
                "page":7,
                "link":"https://www.google.com/scholar?start=60&q=Bluetooth&hl=it&as_sdt=0,5"
            },
            {
                "page":8,
                "link":"https://www.google.com/scholar?start=70&q=Bluetooth&hl=it&as_sdt=0,5"
            },
            {
                "page":9,
                "link":"https://www.google.com/scholar?start=80&q=Bluetooth&hl=it&as_sdt=0,5"
            },
            {
                "page":10,
                "link":"https://www.google.com/scholar?start=90&q=Bluetooth&hl=it&as_sdt=0,5"
            }
        ],
        "api_pagination":{
            "next":"https://api.scaleserp.com/search?api_key=1309E7D70BD240F5AA828E0010EA5E8A&search_type=scholar&q=Bluetooth&id=req0&page=3",
            "other_pages":[
                {
                    "page":1,
                    "link":"https://api.scaleserp.com/search?api_key=1309E7D70BD240F5AA828E0010EA5E8A&search_type=scholar&q=Bluetooth&id=req0&page=1"
                },
                {
                    "page":3,
                    "link":"https://api.scaleserp.com/search?api_key=1309E7D70BD240F5AA828E0010EA5E8A&search_type=scholar&q=Bluetooth&id=req0&page=3"
                },
                {
                    "page":4,
                    "link":"https://api.scaleserp.com/search?api_key=1309E7D70BD240F5AA828E0010EA5E8A&search_type=scholar&q=Bluetooth&id=req0&page=4"
                },
                {
                    "page":5,
                    "link":"https://api.scaleserp.com/search?api_key=1309E7D70BD240F5AA828E0010EA5E8A&search_type=scholar&q=Bluetooth&id=req0&page=5"
                },
                {
                    "page":6,
                    "link":"https://api.scaleserp.com/search?api_key=1309E7D70BD240F5AA828E0010EA5E8A&search_type=scholar&q=Bluetooth&id=req0&page=6"
                },
                {
                    "page":7,
                    "link":"https://api.scaleserp.com/search?api_key=1309E7D70BD240F5AA828E0010EA5E8A&search_type=scholar&q=Bluetooth&id=req0&page=7"
                },
                {
                    "page":8,
                    "link":"https://api.scaleserp.com/search?api_key=1309E7D70BD240F5AA828E0010EA5E8A&search_type=scholar&q=Bluetooth&id=req0&page=8"
                },
                {
                    "page":9,
                    "link":"https://api.scaleserp.com/search?api_key=1309E7D70BD240F5AA828E0010EA5E8A&search_type=scholar&q=Bluetooth&id=req0&page=9"
                },
                {
                    "page":10,
                    "link":"https://api.scaleserp.com/search?api_key=1309E7D70BD240F5AA828E0010EA5E8A&search_type=scholar&q=Bluetooth&id=req0&page=10"
                }
            ]
        }
    },
    "scholar_results":[
        {
            "position":1,
            "title":"[LIBRO][B] Bluetooth Implementation and Use",
            "link":"https://dl.acm.org/doi/abs/10.5555/572577",
            "domain":"dl.acm.org",
            "displayed_link":"R Morrow - 2002 - dl.acm.org",
            "snippet":"… futuristic Bluetooth … Bluetooth module* Probe the math behind the specifications for further \nresearch THE HANDS ON GUIDE TO BLUETOOTH Anyone tackling a job involving Bluetooth …",
            "cited_by_count":258,
            "cited_by_link":"https://www.google.com/scholar?cites=17709113738380096822&as_sdt=2005&sciodt=0,5&hl=it",
            "versions_count":3,
            "versions_link":"https://www.google.com/scholar?cluster=17709113738380096822&hl=it&as_sdt=0,5"
        },
        {
            "position":2,
            "title":"[PDF][PDF] Bluetooth 4.0: low energy",
            "link":"https://www.ineltek.com/wp-content/uploads/2015/09/20160330-IEEE_BLE.pdf",
            "domain":"www.ineltek.com",
            "displayed_link":"J Decuir - Cambridge, UK: Cambridge Silicon Radio SR plc, 2010 - ineltek.com",
            "pdf_link":"https://www.ineltek.com/wp-content/uploads/2015/09/20160330-IEEE_BLE.pdf",
            "snippet":"… Bluetooth low energy has even better low power technology Bluetooth has a commanding \npresence in several large existing markets: mobile phones, automobiles, consumer electronics…",
            "cited_by_count":94,
            "cited_by_link":"https://www.google.com/scholar?cites=1595385961952404287&as_sdt=2005&sciodt=0,5&hl=it",
            "versions_count":2,
            "versions_link":"https://www.google.com/scholar?cluster=1595385961952404287&hl=it&as_sdt=0,5"
        },
        {
            "position":3,
            "title":"[PDF][PDF] Bluetooth security",
            "link":"http://www.yuuhaw.com/bluesec.pdf",
            "domain":"www.yuuhaw.com",
            "displayed_link":"JT Vainio - Proceedings of Helsinki University of Technology …, 2000 - yuuhaw.com",
            "pdf_link":"http://www.yuuhaw.com/bluesec.pdf",
            "snippet":"… Bluetooth is one of the solutions to form a cablefree environment. This paper concentrates \non the security measures of Bluetooth, … Bluetooth can be used for everyday communications. …",
            "cited_by_count":142,
            "cited_by_link":"https://www.google.com/scholar?cites=11053291238463195841&as_sdt=2005&sciodt=0,5&hl=it",
            "versions_count":3,
            "versions_link":"https://www.google.com/scholar?cluster=11053291238463195841&hl=it&as_sdt=0,5"
        },
        {
            "position":4,
            "title":"The Bluetooth radio system",
            "link":"https://ieeexplore.ieee.org/abstract/document/824570/",
            "domain":"ieeexplore.ieee.org",
            "displayed_link":"JC Haartsen - IEEE personal communications, 2000 - ieeexplore.ieee.org",
            "snippet":"… Bluetooth/sup TM/ is an effort by a consortium of companies to design a royalty-free … This \narticle describes the radio system behind the Bluetooth concept. Designing an ad hoc radio …",
            "cited_by_count":1176,
            "cited_by_link":"https://www.google.com/scholar?cites=7466084511368062688&as_sdt=2005&sciodt=0,5&hl=it",
            "versions_count":6,
            "versions_link":"https://www.google.com/scholar?cluster=7466084511368062688&hl=it&as_sdt=0,5"
        },
        {
            "position":5,
            "title":"[LIBRO][B] Bluetooth for JAVA",
            "link":"https://link.springer.com/content/pdf/10.1007/978-1-4302-0763-4.pdf",
            "domain":"link.springer.com",
            "displayed_link":"B Hopkins, R Antony - 2003 - Springer",
            "pdf_link":"https://link.springer.com/content/pdf/10.1007/978-1-4302-0763-4.pdf",
            "snippet":"… of the Bluetooth protocol. Here we define the roles and relationships between the Bluetooth \nstack, Bluetooth profiles, and Bluetooth hardware. If you've seen Bluetooth terminology …",
            "cited_by_count":140,
            "cited_by_link":"https://www.google.com/scholar?cites=2685292102738666477&as_sdt=2005&sciodt=0,5&hl=it",
            "versions_count":5,
            "versions_link":"https://www.google.com/scholar?cluster=2685292102738666477&hl=it&as_sdt=0,5"
        },
        {
            "position":6,
            "title":"[PDF][PDF] Guide to bluetooth security",
            "link":"https://ciphersolutionsblog.com/wp-content/uploads/2022/06/nist.sp_.800-121r2-upd1-1.pdf",
            "domain":"ciphersolutionsblog.com",
            "displayed_link":"J Padgette, K Scarfone, L Chen - NIST special publication, 2017 - ciphersolutionsblog.com",
            "pdf_link":"https://ciphersolutionsblog.com/wp-content/uploads/2022/06/nist.sp_.800-121r2-upd1-1.pdf",
            "snippet":"… security capabilities of Bluetooth and gives recommendations to organizations employing \nBluetooth wireless technologies on securing them effectively. The Bluetooth versions within …",
            "cited_by_count":219,
            "cited_by_link":"https://www.google.com/scholar?cites=11472046818939593078&as_sdt=2005&sciodt=0,5&hl=it",
            "versions_count":16,
            "versions_link":"https://www.google.com/scholar?cluster=11472046818939593078&hl=it&as_sdt=0,5"
        },
        {
            "position":7,
            "title":"[LIBRO][B] Bluetooth security",
            "link":"https://books.google.com/books?hl=it&lr=&id=-fUR0OGZ7bQC&oi=fnd&pg=PR11&dq=Bluetooth&ots=RCczaxPI5F&sig=EFVm9IHWdI-rfmjfSVPbtTa1_k0",
            "domain":"books.google.com",
            "displayed_link":"C Gehrmann, J Persson, B Smeets - 2004 - books.google.com",
            "snippet":"\" This resource examine the most significant attacks on Bluetooth security mechanisms and \ntheir implementations, demonstrating how some of these known weaknesses can be …",
            "cited_by_count":134,
            "cited_by_link":"https://www.google.com/scholar?cites=4070608431183920469&as_sdt=2005&sciodt=0,5&hl=it",
            "versions_count":5,
            "versions_link":"https://www.google.com/scholar?cluster=4070608431183920469&hl=it&as_sdt=0,5"
        },
        {
            "position":8,
            "title":"Ricocheting bluetooth",
            "link":"https://ieeexplore.ieee.org/abstract/document/895713/",
            "domain":"ieeexplore.ieee.org",
            "displayed_link":"DJY Lee, WCY Lee - ICMMT 2000. 2000 2nd International …, 2000 - ieeexplore.ieee.org",
            "snippet":"… Bluetooth forum and the genera1 belief is that within perceivable future all devices will \nhave Bluetooth … the nature of IP network through Bluetooth to relay the mobile voice within …",
            "cited_by_count":57,
            "cited_by_link":"https://www.google.com/scholar?cites=17451867787031344647&as_sdt=2005&sciodt=0,5&hl=it",
            "versions_link" : "aa"
        },
        {
            "position":9,
            "title":"Bluetooth in wireless communication",
            "link":"https://ieeexplore.ieee.org/abstract/document/1007414/",
            "domain":"ieeexplore.ieee.org",
            "displayed_link":"K Sairam, N Gunasekaran… - IEEE Communications …, 2002 - ieeexplore.ieee.org",
            "snippet":"… It also describes the functional overview and applications of Bluetooth, and deals with the … \nvia Bluetooth using IISS. Industrial automation is one of the major applications of Bluetooth tech…",
            "cited_by_count":298,
            "cited_by_link":"https://www.google.com/scholar?cites=6114840824384512682&as_sdt=2005&sciodt=0,5&hl=it",
            "versions_count":7,
            "versions_link":"https://www.google.com/scholar?cluster=6114840824384512682&hl=it&as_sdt=0,5"
        },
        {
            "position":10,
            "title":"[LIBRO][B] Bluetooth 1.1: connect without cables",
            "link":"https://books.google.com/books?hl=it&lr=&id=mUyiREePWHwC&oi=fnd&pg=PT3&dq=Bluetooth&ots=0DoBV7vtOu&sig=nQSxL_LXsAWxxSyUCBxzULCtxw8",
            "domain":"books.google.com",
            "displayed_link":"J Bray, CF Sturman - 2001 - books.google.com",
            "snippet":"… to the new Bluetooth 1.1 specification Bluetooth 1.1's dramatic … of Bluetooth security and \npower conservation New Bluetooth … The first complete guide to the new Bluetooth 1.1 wireless …",
            "cited_by_count":884,
            "cited_by_link":"https://www.google.com/scholar?cites=3321664509668345985&as_sdt=2005&sciodt=0,5&hl=it",
            "versions_count":5,
            "versions_link":"https://www.google.com/scholar?cluster=3321664509668345985&hl=it&as_sdt=0,5"
        }
    ]
}

// export {data};
module.exports = {data};