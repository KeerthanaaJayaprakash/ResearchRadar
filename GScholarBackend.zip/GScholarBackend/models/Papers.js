const mongoose = require("mongoose");

const paperSchema =  new mongoose.Schema({
  request_info: {
      success: Boolean,
      credits_used: Number,
      credits_used_this_request: Number,
      credits_remaining: Number,
      credits_reset_at: Date
  },
  search_parameters: {
      search_type: String,
      q: String,
      id: String,
      page: String,
      engine: String
  },
  search_metadata: {
      created_at: Date,
      processed_at: Date,
      total_time_taken: Number,
      engine_url: String,
      html_url: String,
      json_url: String
  },
  search_information: {
      original_query_yields_zero_results: Boolean,
      total_results: Number,
      time_taken_displayed: Number,
      query_displayed: String
  },
  pagination: {
      current: Number,
      next: String,
      other_pages: [
          {
              page: Number,
              link: String
          }
      ],
      api_pagination: {
          next: String,
          other_pages: [
              {
                  page: Number,
                  link: String
              }
          ]
      }
  },
  scholar_results: [
      {
          position: Number,
          title: String,
          link: String,
          domain: String,
          displayed_link: String,
          snippet: String,
          cited_by_count: Number,
          cited_by_link: String,
          versions_count: Number,
          versions_link: String,
      }
  ]
});



module.exports = mongoose.model("Papers", paperSchema);



