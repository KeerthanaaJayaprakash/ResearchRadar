const express = require('express');
const mongoose = require("mongoose");

const app = express();
const port = 4444;



app.use(express.json({}));
app.use(
    express.json({
        extended: true,
    })
);
app.use(express.urlencoded({ extended: true }));

// mongoose.connect("mongodb://localhost/GScholar",
//     err => {
//         if(err) throw err;
//         console.log('connected to MongoDB')
//     });


mongoose.connect("mongodb://localhost:27017/GScholar", {
   useNewUrlParser: true,
   useUnifiedTopology: true
});



app.use('/users',require("./routes/users"));
app.use('/search',require("./routes/search"));

app.get('/', (req, res) => {
    res.send('Hello World!');
    console.log("AAA")
  });

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});

// const axios = require('axios');

// // set up the request parameters
// const params = {
// api_key: "1309E7D70BD240F5AA828E0010EA5E8A",
//   search_type: "scholar",
//   q: "wifi"
// }

// // make the http GET request to Scale SERP
// axios.get('https://api.scaleserp.com/search', { params })
// .then(response => {

//     // print the JSON response from Scale SERP
//     console.log(JSON.stringify(response.data, 0, 2));

//   }).catch(error => {
// // catch and print the error
// console.log(error);
// })