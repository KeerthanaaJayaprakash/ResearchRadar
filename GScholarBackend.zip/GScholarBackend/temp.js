 
// const html= ""

axios.get("https://dl.acm.org/doi/abs/10.5555/559939")
.then(response => {
const html = response.data;
printD(html)
// console.log(html)
// const isAbstract =  html.search("ABSTRACT")

// console.log(isAbstract)
// const $ = cheerio.load(html);

// $("h1").each((index, element) =>

// {console.log($(element).text ());

// });
// console.log(html)
// Continue with scraping logic
}).catch(error => {
console.error("Error:", error);

});

function printD(html){

    const $ = cheerio.load(html);

    $("p").each((index, element) =>

    {console.log($(element).text ());

    });
}

function printWithJS(html){
const puppeteer = require("puppeteer");

(async () => {


const browser = await puppeteer.launch ();

const page = await browser.newPage ();




await browser.close ();

}) (); 
}